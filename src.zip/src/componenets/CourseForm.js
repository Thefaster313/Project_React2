import React from 'react';

const CourseForm =(props)=>{

return(
    <form onSubmit={props.Addcourse}>
<input type ="text" value={props.current} onChange={props.update} />
<button type="submit" >Add Cours </button>
       
    </form>
    
    )


}
export default CourseForm;